# tests/test_queue_play.py
import pytest
import create_video_list as cvl

# Create a list of dummy library items for testing
dummy_library_items = [
    {"title": "Test Title 1", "director": "Test Director 1", "year": 2020},
    {"title": "Test Title 2", "director": "Test Director 2", "year": 2021},
    {"title": "Test Title 3", "director": "Test Director 3", "year": 2022},
]

# Test functions in create_list_queue
def test_create_list_queue():
    queue = CreateListQueue()
    for item in dummy_library_items:
        queue.add_item(item)
    assert len(queue.queue) == len(dummy_library_items)

def test_create_list_queue_empty():
    queue = CreateListQueue()
    assert len(queue.queue) == 0

# Test functions in play
def test_play():
    queue = CreateListQueue()
    for item in dummy_library_items:
        queue.add_item(item)
    play = Play(queue)
    play.play_next()
    assert play.current_item == dummy_library_items[0]

def test_play_next():
    queue = CreateListQueue()
    for item in dummy_library_items:
        queue.add_item(item)
    play = Play(queue)
    play.play_next()
    play.play_next()
    assert play.current_item == dummy_library_items[1]

def test_play_previous():
    queue = CreateListQueue()
    for item in dummy_library_items:
        queue.add_item(item)
    play = Play(queue)
    play.play_next()
    play.play_next()
    play.play_previous()
    assert play.current_item == dummy_library_items[0]

def test_play_empty_queue():
    queue = CreateListQueue()
    play = Play(queue)
    with pytest.raises(IndexError):
        play.play_next()